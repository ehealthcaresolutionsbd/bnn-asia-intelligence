<?php
/**
 * Plugin Name: BNN Asia Autopilot Bridge
 * Description: Lets the BNN Asia n8n automation upload an image and create Country News posts, and nothing else. Uses one secret key (generated here, stored only as a hash) instead of Application Passwords.
 * Version: 1.0.0
 * Author: BNN Asia
 * Requires PHP: 7.4
 */

defined( 'ABSPATH' ) || exit;

final class BNN_Autopilot_Bridge {

	const OPT_HASH   = 'bnn_autopilot_key_hash';
	const OPT_AUTHOR = 'bnn_autopilot_author';
	const NS         = 'bnn-autopilot/v1';
	const POST_TYPE  = 'country_news';
	const TAXONOMY   = 'country_select';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
	}

	/* ---------- Authentication: header X-BNN-Key, compared as a SHA-256 hash ---------- */

	public static function authorised( WP_REST_Request $req ) {
		$hash = get_option( self::OPT_HASH );
		$key  = (string) $req->get_header( 'x_bnn_key' );
		if ( ! $hash || strlen( $key ) < 32 ) {
			return new WP_Error( 'bnn_autopilot_forbidden', 'Not allowed.', array( 'status' => 401 ) );
		}
		if ( ! hash_equals( $hash, hash( 'sha256', $key ) ) ) {
			return new WP_Error( 'bnn_autopilot_forbidden', 'Not allowed.', array( 'status' => 401 ) );
		}
		// Brute-force guard: at most 300 authorised calls per hour.
		$n = (int) get_transient( 'bnn_autopilot_calls' );
		if ( $n > 300 ) {
			return new WP_Error( 'bnn_autopilot_rate', 'Too many requests.', array( 'status' => 429 ) );
		}
		set_transient( 'bnn_autopilot_calls', $n + 1, HOUR_IN_SECONDS );
		$author = (int) get_option( self::OPT_AUTHOR );
		if ( $author ) {
			wp_set_current_user( $author );
		}
		return true;
	}

	public static function routes() {
		register_rest_route( self::NS, '/media', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'media' ),
			'permission_callback' => array( __CLASS__, 'authorised' ),
		) );
		register_rest_route( self::NS, '/post', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'post' ),
			'permission_callback' => array( __CLASS__, 'authorised' ),
		) );
		register_rest_route( self::NS, '/ping', array(
			'methods'             => 'GET',
			'callback'            => function () {
				return array( 'ok' => true );
			},
			'permission_callback' => array( __CLASS__, 'authorised' ),
		) );
	}

	/** Raw JPEG/PNG body. Query args: filename, alt, caption, title. */
	public static function media( WP_REST_Request $req ) {
		$body = $req->get_body();
		if ( strlen( $body ) < 1000 || strlen( $body ) > 12 * MB_IN_BYTES ) {
			return new WP_Error( 'bnn_autopilot_media', 'Image missing or too large.', array( 'status' => 400 ) );
		}
		$info = @getimagesizefromstring( $body );
		if ( ! $info || ! in_array( $info['mime'], array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) {
			return new WP_Error( 'bnn_autopilot_media', 'Only JPEG, PNG or WebP images.', array( 'status' => 400 ) );
		}
		$ext  = array( 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp' )[ $info['mime'] ];
		$name = sanitize_file_name( (string) $req->get_param( 'filename' ) );
		$name = ( $name ? preg_replace( '/\.[a-z0-9]+$/i', '', $name ) : 'bnn-asia-' . time() ) . '.' . $ext;

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$up = wp_upload_bits( $name, null, $body );
		if ( ! empty( $up['error'] ) ) {
			return new WP_Error( 'bnn_autopilot_media', $up['error'], array( 'status' => 500 ) );
		}
		$title = sanitize_text_field( (string) $req->get_param( 'title' ) );
		$id    = wp_insert_attachment( array(
			'post_mime_type' => $info['mime'],
			'post_title'     => $title ? $title : preg_replace( '/\.[^.]+$/', '', $name ),
			'post_excerpt'   => sanitize_text_field( (string) $req->get_param( 'caption' ) ),
			'post_content'   => sanitize_text_field( (string) $req->get_param( 'alt' ) ),
			'post_status'    => 'inherit',
		), $up['file'] );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $up['file'] ) );
		update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( (string) $req->get_param( 'alt' ) ) );
		return array( 'id' => $id, 'source_url' => wp_get_attachment_url( $id ) );
	}

	/** JSON: title, content, status (draft|future|publish), date_gmt, slug, country_id, featured_media, seo{title,description,focus_keyword}. */
	public static function post( WP_REST_Request $req ) {
		$p      = $req->get_json_params();
		$title  = sanitize_text_field( $p['title'] ?? '' );
		$body   = wp_kses_post( $p['content'] ?? '' );
		$status = in_array( $p['status'] ?? '', array( 'draft', 'future', 'publish' ), true ) ? $p['status'] : 'draft';
		if ( ! $title || strlen( wp_strip_all_tags( $body ) ) < 200 ) {
			return new WP_Error( 'bnn_autopilot_post', 'Title or content missing.', array( 'status' => 400 ) );
		}
		$data = array(
			'post_type'    => self::POST_TYPE,
			'post_title'   => $title,
			'post_content' => $body,
			'post_status'  => $status,
			'post_name'    => sanitize_title( $p['slug'] ?? $title ),
			'post_author'  => (int) get_option( self::OPT_AUTHOR ) ?: 1,
		);
		if ( ! empty( $p['date_gmt'] ) && strtotime( $p['date_gmt'] . ' UTC' ) ) {
			$gmt                    = gmdate( 'Y-m-d H:i:s', strtotime( $p['date_gmt'] . ' UTC' ) );
			$data['post_date_gmt']  = $gmt;
			$data['post_date']      = get_date_from_gmt( $gmt );
			if ( 'future' === $status && strtotime( $gmt . ' UTC' ) <= time() ) {
				$data['post_status'] = 'publish';
			}
		}
		$id = wp_insert_post( $data, true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$country = (int) ( $p['country_id'] ?? 0 );
		if ( $country && term_exists( $country, self::TAXONOMY ) ) {
			wp_set_object_terms( $id, array( $country ), self::TAXONOMY );
		}
		$media = (int) ( $p['featured_media'] ?? 0 );
		if ( $media && 'attachment' === get_post_type( $media ) ) {
			set_post_thumbnail( $id, $media );
		}
		$seo = is_array( $p['seo'] ?? null ) ? $p['seo'] : array();
		foreach ( array( 'title' => 'rank_math_title', 'description' => 'rank_math_description', 'focus_keyword' => 'rank_math_focus_keyword' ) as $k => $meta ) {
			if ( ! empty( $seo[ $k ] ) ) {
				update_post_meta( $id, $meta, sanitize_text_field( $seo[ $k ] ) );
			}
		}
		update_post_meta( $id, '_bnn_autopilot', 1 );
		return array( 'id' => $id, 'status' => get_post_status( $id ), 'link' => get_permalink( $id ), 'date' => get_post_field( 'post_date', $id ) );
	}

	/* ---------- Settings → BNN Autopilot: generate / revoke the key ---------- */

	public static function menu() {
		add_options_page( 'BNN Autopilot', 'BNN Autopilot', 'manage_options', 'bnn-autopilot', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$new = '';
		if ( isset( $_POST['bnn_autopilot_action'] ) && check_admin_referer( 'bnn_autopilot' ) ) {
			if ( 'generate' === $_POST['bnn_autopilot_action'] ) {
				$new = wp_generate_password( 48, false, false );
				update_option( self::OPT_HASH, hash( 'sha256', $new ), false );
				update_option( self::OPT_AUTHOR, get_current_user_id(), false );
			} elseif ( 'revoke' === $_POST['bnn_autopilot_action'] ) {
				delete_option( self::OPT_HASH );
			}
		}
		$has = (bool) get_option( self::OPT_HASH );
		echo '<div class="wrap"><h1>BNN Autopilot</h1><p>This key lets the n8n automation upload images and create <strong>Country News</strong> posts. It cannot do anything else. Only a hash of the key is stored here.</p>';
		if ( $new ) {
			echo '<div class="notice notice-warning"><p><strong>Copy this key now — it will not be shown again.</strong> Paste it into n8n → Credentials → "BNN Autopilot key" → Value.</p><p><code style="font-size:15px;user-select:all">' . esc_html( $new ) . '</code></p></div>';
		}
		echo '<p>Status: ' . ( $has ? '<strong style="color:#11734b">a key is active</strong>' : '<strong>no key</strong>' ) . '</p><form method="post">';
		wp_nonce_field( 'bnn_autopilot' );
		echo '<button class="button button-primary" name="bnn_autopilot_action" value="generate">' . ( $has ? 'Generate a new key (old one stops working)' : 'Generate key' ) . '</button> ';
		if ( $has ) {
			echo '<button class="button" name="bnn_autopilot_action" value="revoke" onclick="return confirm(\'Revoke the key? The automation will stop posting.\')">Revoke key</button>';
		}
		echo '</form></div>';
	}
}
BNN_Autopilot_Bridge::init();
