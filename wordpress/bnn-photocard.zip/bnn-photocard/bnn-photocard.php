<?php
/**
 * Plugin Name: BNN Asia PhotoCard
 * Description: BNN Asia edition (based on News PhotoCard Pro 3.6.0). Generates 1024×1024 BNN Asia cards through the BNN server renderer, plus the original templates. Original: lets you instantly generate 1080×1080 branded photo cards for news posts, blogs, and social media. Design unique cards with fully customizable HTML/CSS templates, add dynamic post data, and share them directly. Includes Elementor widget, shortcode, live preview, and full template manager — perfect for publishers and creators.
 * Version: 3.6.0-bnn.2
 * Author: Rasedul Haque Rumi (original), BNN Asia (BNN edition)
 * Author URI: https://www.facebook.com/rumipro.dev/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: news-photocard-pro
 * Requires at least: 5.8
 * Tested up to: 6.6
 * Requires PHP: 7.4
 * Tags: news, photo card, elementor, social media, image generator, design, template builder, content branding
 */

/**
 * News PhotoCard Pro
 *
 * A professional photo card generator plugin for WordPress.
 * Create, customize, and share engaging social-ready photo cards directly from your WordPress dashboard.
 *
 * 🌟 Key Features:
 * - Fully editable HTML/CSS template system
 * - Dynamic post data (title, excerpt, image, category, CTA)
 * - Elementor widget with customizable design options
 * - Shortcode support for embedding anywhere
 * - Live preview and instant image export
 * - Developer-friendly hooks and filters
 * - Translation-ready with text domain support
 *
 * Ideal for:
 * 📰 News portals, 🧑‍💻 Bloggers, 🎨 Designers, and 📣 Social media marketers
 * who want fast, on-brand visuals without external tools like Canva.
 */

if (!defined('ABSPATH')) exit;
require_once plugin_dir_path(__FILE__) . 'includes/class-photocard-core.php';
add_action('elementor/widgets/register', function($widgets_manager){
    require_once plugin_dir_path(__FILE__) . 'includes/class-elementor-widget.php';
    $widgets_manager->register(new UDNPC_Elementor_Widget());
});
