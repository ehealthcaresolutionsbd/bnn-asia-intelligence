=== News PhotoCard Pro ===
Contributors: rashedulhaquerumi,synthiasoft
Tags: news, elementor, social media, template, design
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 3.6.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create customizable 1080×1080 photo cards from posts with templates, Elementor widget, and shortcode support.

== Description ==

**News PhotoCard Pro** helps publishers, bloggers, and creators generate branded 1080×1080 photo cards directly from WordPress.  
Design dynamic cards with HTML/CSS templates, include post title, featured image, and CTA — then export or share instantly.

### ✨ Key Features

- Fully editable HTML & CSS template system  
- Dynamic post data (title, image, date, category)  
- Elementor widget + `[news_photocard_button]` shortcode  
- Auto “Download PhotoCard” button on post pages  
- Live preview and instant export (via bundled html2canvas)  
- No external CDN — all assets are locally bundled  
- Translation ready with `.pot` file support  

### Ideal for:
📰 News sites, 🧑‍💻 Bloggers, 🎨 Designers, 📣 Social media marketers

== Installation ==

1. Upload `news-photocard-pro` to `/wp-content/plugins/`.  
2. Activate from **Plugins → Installed Plugins**.  
3. Go to **PhotoCard → Settings** to pick your design template.  
4. Customize template options (logo, colors, CTA text).  
5. Use the shortcode or Elementor widget to display your button.

== Usage ==

**Automatic Button:**  
Enable “Auto Button” to add a *Download PhotoCard* button to posts.

**Shortcode Example:**  

[news_photocard_button text="Download PhotoCard"]



**Elementor Widget:**  
Drag and drop the *News PhotoCard Button* widget to any Elementor section and customize text, colors, and placement.

**Template Customization:**  
You can edit or create your own template files under:  
`/wp-content/plugins/news-photocard-pro/templates/`

Each template supports PHP arrays for fields, default colors, and custom HTML/CSS rendering.

== Frequently Asked Questions ==

= Can I add my own design templates? =  
Yes! Each template is defined as a simple PHP array in the `/templates/` folder. You can copy an existing one and modify it freely.

= Does it require Elementor? =  
No. Elementor is optional. The plugin works perfectly with classic themes or block editor — just use the shortcode.

= Where are the generated images stored? =  
Images are rendered directly in the browser using HTML2Canvas, so nothing is uploaded to your server.

= Can I use this on a multi-site? =  
Yes, the plugin is fully compatible with WordPress multisite installations.

= Does it load any external resources? =  
No. All assets, including `html2canvas`, are now included locally inside the plugin folder for full compliance with WordPress.org standards.

== Screenshots ==
1. We Have 6 Templates Total. You can use your loved One.
2. Admin settings page with live template options  
3. Auto “Download PhotoCard” button on a single post  
4. Example generated 1080×1080 photo card  


== Changelog ==

= 3.6.0 =
* Initial public release  
* Added full admin settings page  
* Added live template field rendering  
* Added shortcode `[news_photocard_button]`  
* Added Elementor widget integration  
* Included local `html2canvas` support  
* Fully compliant with WordPress.org coding standards  

== Upgrade Notice ==

= 3.6.0 =
Major stable release — includes Elementor widget, shortcode support, and compliance with WordPress Plugin Check.

== Credits ==

Developed and maintained by **Rasedul Haque Rumi**  
📘 Facebook: [https://www.facebook.com/rumipro.dev/](https://www.facebook.com/rumipro.dev/)
🌐 Website: [https://rashedulhaque.com/](https://rashedulhaque.com/)

== License ==

This plugin is licensed under the GNU General Public License v2 or later.  
You are free to modify and redistribute it under the same license.