<?php
/* BNN Asia card: drawn on the BNN server (api.bnnasia.org) so the website button and the n8n automation
   produce exactly the same 1024x1024 image. Layout: photo full-bleed, logo top-left, black shade at the
   bottom with red country label and white headline, BNN Asia footer line. */
return [
  'key'    => 'bnn-asia',
  'name'   => 'BNN Asia (server-rendered, 1024×1024)',
  'server' => true,
  'fields' => [
    'server_url' => ['type'=>'text', 'label'=>'Renderer URL', 'default'=>'https://api.bnnasia.org/api/v1/photocard.png'],
  ],
  'css'  => '/* drawn on the server */',
  'html' => '<div class="udnpc-card"></div>',
];
