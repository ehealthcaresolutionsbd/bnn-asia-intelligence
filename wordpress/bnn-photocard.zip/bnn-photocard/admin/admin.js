(function($){
  function mediaPicker(inputId){
    const frame = wp.media({ title:'Select Image', button:{text:'Use this image'}, multiple:false });
    frame.on('select', function(){ const a=frame.state().get('selection').first().toJSON(); $('#'+inputId).val(a.url); });
    frame.open();
  }
  function renderFields(schema, values){
    const $wrap=$('#udnpc-dynamic-fields').empty();
    Object.keys(schema).forEach(function(key){
      const field=schema[key]; const id='tpl_'+key; const val=(values&&values[key])||field.default||'';
      const $row=$('<div class="udnpc-field-row"/>');
      const $label=$('<label class="udnpc-label" for="'+id+'"/>').text(field.label||key);
      let $input;
      if(field.type==='color'){ $input=$('<input type="text" class="udnpc-color" id="'+id+'" name="'+id+'" />').val(val); }
      else if(field.type==='image'){ $input=$('<div class="udnpc-image-field"><input type="text" id="'+id+'" name="'+id+'" value="'+val+'" /><button class="button udnpc-pick" data-target="'+id+'">Select</button></div>'); }
      else { $input=$('<input type="text" id="'+id+'" name="'+id+'" />').val(val); }
      $row.append($label).append($input); $wrap.append($row);
    });
    $('.udnpc-color').wpColorPicker();
    $wrap.off('click','.udnpc-pick').on('click','.udnpc-pick', function(e){ e.preventDefault(); mediaPicker($(this).data('target')); });
  }
  function loadTemplateUI(){
    const tpls=UDNPCAdmin.templates||{}; const active=$('#udnpc-active-template').val(); const schema=(tpls[active]&&tpls[active].fields)||{};
    renderFields(schema,{});
    $.post(UDNPCAdmin.ajax,{action:'udnpcv36_get_saved_options',key:active,_ajax_nonce:UDNPCAdmin.nonce||''}, function(resp){
      if(resp&&resp.success&&resp.data){ renderFields(schema, resp.data); }
    }, 'json');
  }
  $(document).on('change','#udnpc-active-template', loadTemplateUI);
  $(document).ready(loadTemplateUI);
})(jQuery);