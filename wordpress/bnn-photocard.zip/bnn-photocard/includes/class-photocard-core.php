<?php
if (!defined('ABSPATH')) exit;

class UDNPC_Core {
    const OPT_CORE   = 'udnpc_core_v3_6';
    const OPT_PREFIX = 'udnpc_tpl_opts_v3_6_';
    const MENU_SLUG  = 'news-photocard-pro';

    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_enqueue_scripts', [$this, 'admin_enqueue']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_front_assets']);
        add_action('the_content', [$this, 'inject_button']);
        add_shortcode('news_photocard_button', [$this, 'shortcode_button']);

        add_action('wp_ajax_udnpc_get_card', [$this, 'ajax_get_card_data']);
        add_action('wp_ajax_nopriv_udnpc_get_card', [$this, 'ajax_get_card_data']);
        add_action('wp_ajax_udnpcv36_get_saved_options', [$this, 'ajax_get_saved_options']);
    }

    /* ---------- Templates ---------- */
    public function templates_dir() {
        return plugin_dir_path(__FILE__) . '../templates/';
    }

    public function list_templates() {
        $files = glob($this->templates_dir() . '*.php');
        $out = [];
        if ($files) {
            foreach ($files as $file) {
                $def = include $file;
                if (is_array($def) && !empty($def['key']) && !empty($def['name']) && !empty($def['fields']) && !empty($def['css']) && !empty($def['html'])) {
                    $out[$def['key']] = $def;
                }
            }
        }
        return $out;
    }

    private function core_defaults() {
        return [
            'active_template' => array_key_first($this->list_templates()),
            'show_button'     => '1',
            'button_position' => 'end',
            'button_text'     => '📸 Download News PhotoCard (1080×1080)',
        ];
    }

    public function get_core() {
        $core = get_option(self::OPT_CORE, []);
        if (!is_array($core)) {
            $core = [];
        }
        return wp_parse_args($core, $this->core_defaults());
    }

    public function get_active_template_key() {
        $core = $this->get_core();
        $tpls = $this->list_templates();
        $first = array_key_first($tpls);
        return (!empty($core['active_template']) && isset($tpls[$core['active_template']])) ? $core['active_template'] : $first;
    }

    public function get_template_options($tpl_key) {
        $opt_key = self::OPT_PREFIX . sanitize_key($tpl_key);
        $opts = get_option($opt_key, []);
        if (!is_array($opts)) {
            $opts = [];
        }

        $tpls = $this->list_templates();
        if (isset($tpls[$tpl_key])) {
            foreach ($tpls[$tpl_key]['fields'] as $k => $field) {
                if (!isset($opts[$k]) && isset($field['default'])) {
                    $opts[$k] = $field['default'];
                }
            }
        }
        return $opts;
    }

    /* ---------- Admin ---------- */
    public function add_menu() {
        add_menu_page(
            __('News PhotoCard', 'news-photocard-pro'),
            __('PhotoCard', 'news-photocard-pro'),
            'manage_options',
            self::MENU_SLUG,
            [$this, 'settings_page'],
            'dashicons-format-image',
            56
        );
        add_submenu_page(
            self::MENU_SLUG,
            __('Settings', 'news-photocard-pro'),
            __('Settings', 'news-photocard-pro'),
            'manage_options',
            self::MENU_SLUG,
            [$this, 'settings_page']
        );
    }

    public function admin_enqueue($hook) {
        if (strpos($hook, self::MENU_SLUG) === false) return;

        wp_enqueue_media();
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_style('udnpc-admin', plugin_dir_url(__FILE__) . '../admin/admin.css', [], '3.7.0');
        wp_enqueue_script('udnpc-admin', plugin_dir_url(__FILE__) . '../admin/admin.js', ['jquery', 'wp-color-picker'], '3.7.0', true);

        wp_localize_script('udnpc-admin', 'UDNPCAdmin', [
            'templates' => $this->list_templates(),
            'core'      => $this->get_core(),
            'opts'      => $this->get_template_options($this->get_active_template_key()),
            'nonce'     => wp_create_nonce('udnpcv36_nonce'),
            'ajax'      => admin_url('admin-ajax.php'),
        ]);
    }

    public function settings_page() {
        if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
            $nonce = isset($_POST['udnpcv36_nonce']) ? sanitize_text_field(wp_unslash($_POST['udnpcv36_nonce'])) : '';
            if ($nonce && wp_verify_nonce($nonce, 'udnpcv36_save')) {
                $tpls = $this->list_templates();
                $active_template = isset($_POST['active_template']) ? sanitize_text_field(wp_unslash($_POST['active_template'])) : '';
                if (!isset($tpls[$active_template])) {
                    $active_template = $this->get_active_template_key();
                }

                $show_button = isset($_POST['show_button']) ? '1' : '0';
                $button_position = isset($_POST['button_position']) ? sanitize_text_field(wp_unslash($_POST['button_position'])) : 'end';
                $button_position = in_array($button_position, ['start', 'end'], true) ? $button_position : 'end';
                $button_text = isset($_POST['button_text']) ? sanitize_text_field(wp_unslash($_POST['button_text'])) : '';

                update_option(self::OPT_CORE, [
                    'active_template' => $active_template,
                    'show_button'     => $show_button,
                    'button_position' => $button_position,
                    'button_text'     => $button_text ?: $this->core_defaults()['button_text'],
                ]);

                $fields = $tpls[$active_template]['fields'];
                $saved  = [];
                foreach ($fields as $fkey => $field) {
                    $input_name = 'tpl_' . $fkey;
                    // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized immediately after
                    $raw_val = isset($_POST[$input_name]) ? wp_unslash($_POST[$input_name]) : '';
                    if ($field['type'] === 'color') {
                        $val = sanitize_hex_color($raw_val);
                    } else {
                        $val = sanitize_text_field($raw_val);
                    }
                    $saved[$fkey] = $val;
                }
                update_option(self::OPT_PREFIX . $active_template, $saved);

                echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Settings saved.', 'news-photocard-pro') . '</p></div>';
            }
        }

        $tpls = $this->list_templates();
        $core = $this->get_core();
        $active = $this->get_active_template_key();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('News PhotoCard — Templates & Button', 'news-photocard-pro'); ?></h1>
            <form method="post">
                <?php wp_nonce_field('udnpcv36_save', 'udnpcv36_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="udnpc-active-template"><?php esc_html_e('Design Template', 'news-photocard-pro'); ?></label></th>
                        <td>
                            <select id="udnpc-active-template" name="active_template">
                                <?php foreach ($tpls as $k => $t): ?>
                                    <option value="<?php echo esc_attr($k); ?>" <?php selected($k, $active); ?>>
                                        <?php echo esc_html($t['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Show Auto Button on Post', 'news-photocard-pro'); ?></th>
                        <td><label><input type="checkbox" name="show_button" value="1" <?php checked($core['show_button'], '1'); ?> /> <?php esc_html_e('Enable', 'news-photocard-pro'); ?></label></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Button Position', 'news-photocard-pro'); ?></th>
                        <td>
                            <label><input type="radio" name="button_position" value="start" <?php checked($core['button_position'], 'start'); ?> /> <?php esc_html_e('Start of post', 'news-photocard-pro'); ?></label>
                            &nbsp;&nbsp;
                            <label><input type="radio" name="button_position" value="end" <?php checked($core['button_position'], 'end'); ?> /> <?php esc_html_e('End of post', 'news-photocard-pro'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="udnpc-button-text"><?php esc_html_e('Auto Button Text', 'news-photocard-pro'); ?></label></th>
                        <td><input type="text" id="udnpc-button-text" name="button_text" value="<?php echo esc_attr($core['button_text']); ?>" style="min-width:420px"></td>
                    </tr>
                </table>
                <h2><?php esc_html_e('Template Options', 'news-photocard-pro'); ?></h2>
                <div id="udnpc-dynamic-fields"></div>
                <?php submit_button(__('Save Settings', 'news-photocard-pro')); ?>
            </form>
            <h2><?php esc_html_e('Shortcode', 'news-photocard-pro'); ?></h2>
            <p><code>[news_photocard_button text="Your custom text"]</code></p>
        </div>
        <?php
    }

    /* ---------- Front ---------- */
    public function enqueue_front_assets() {
        if (!is_single() || !$this->button_allowed()) return;

        wp_enqueue_style('udnpc-fonts', plugin_dir_url(__FILE__) . '../assets/fonts.css', [], '3.7.0');
        wp_enqueue_style('udnpc-el-btn', plugin_dir_url(__FILE__) . '../assets/elementor-button.css', [], '3.7.0');
        wp_enqueue_script('html2canvas', plugin_dir_url(__FILE__) . '../assets/html2canvas.min.js', [], '1.4.1', true);
        wp_enqueue_script('udnpc-front', plugin_dir_url(__FILE__) . '../assets/front.js', ['html2canvas', 'jquery'], '3.7.0', true);

        $tpl_key = $this->get_active_template_key();
        $opts    = $this->get_template_options($tpl_key);
        $tpls    = $this->list_templates();
        $tpl_def = isset($tpls[$tpl_key]) ? [
            'key'  => $tpls[$tpl_key]['key'],
            'css'  => $tpls[$tpl_key]['css'],
            'html' => $tpls[$tpl_key]['html'],
        ] : null;

        $core = $this->get_core();
        wp_localize_script('udnpc-front', 'UDNPCF', [
            'ajax'        => admin_url('admin-ajax.php'),
            'nonce'       => wp_create_nonce('udnpcv36f'),
            'tpl'         => $tpl_key,
            'opts'        => $opts,
            'tpl_def'     => $tpl_def,
            'button_text' => $core['button_text'],
        ]);
    }

    /** The BNN card is an internal tool: only people who can edit posts see the button. */
    private function button_allowed() {
        $tpls = $this->list_templates();
        $key  = $this->get_active_template_key();
        return empty($tpls[$key]['server']) || current_user_can('edit_posts');
    }

    public function inject_button($content) {
        if (!is_single() || !has_post_thumbnail() || !$this->button_allowed()) {
            return $content;
        }

        $core = $this->get_core();
        if ($core['show_button'] !== '1') {
            return $content;
        }

        $post_id = get_the_ID();
        $btn_html = sprintf(
            '<div class="udnpc-wrap"><input type="hidden" id="udnpc-postid" value="%d"><button id="udnpc-generate" class="udnpc-elementor-btn button button-primary">%s</button></div>',
            esc_attr($post_id),
            esc_html($core['button_text'])
        );

        return ($core['button_position'] === 'start') ? $btn_html . $content : $content . $btn_html;
    }

    public function shortcode_button($atts = [], $content = '') {
        $atts = shortcode_atts(['text' => ''], $atts, 'news_photocard_button');
        $text = $atts['text'] ?: $this->get_core()['button_text'];
        $post_id = get_the_ID();
        if (!$post_id || !has_post_thumbnail($post_id) || !$this->button_allowed()) return '';
        return sprintf(
            '<div class="udnpc-wrap"><input type="hidden" id="udnpc-postid" value="%d"><button id="udnpc-generate" class="udnpc-elementor-btn button button-primary">%s</button></div>',
            esc_attr($post_id),
            esc_html($text)
        );
    }

    /* ---------- AJAX ---------- */
    public function ajax_get_card_data() {
        $domain = isset($_SERVER['SERVER_NAME']) ? sanitize_text_field(wp_unslash($_SERVER['SERVER_NAME'])) : 'example.com';
        $domain = preg_replace('/^www\./', '', $domain);

        check_ajax_referer('udnpcv36f', 'nonce');
        $post_id = isset($_POST['post_id']) ? intval(wp_unslash($_POST['post_id'])) : 0;
        if (!$post_id) wp_send_json_error(['message' => 'Invalid post id']);

        $title = get_the_title($post_id);
        $date  = date_i18n('d F Y', get_post_time('U', true, $post_id));
        $image = get_the_post_thumbnail_url($post_id, 'full');
        $site  = get_bloginfo('name');
        if (!$image) wp_send_json_error(['message' => 'No featured image on this post.']);

        $tpl_key = $this->get_active_template_key();
        $opts    = $this->get_template_options($tpl_key);
        if (!is_array($opts)) $opts = [];

        $raw_title = trim(wp_strip_all_tags((string) $title));
        $words     = preg_split('/\s+/u', $raw_title, -1, PREG_SPLIT_NO_EMPTY);
        $opts['wc'] = is_array($words) ? count($words) : 0;
        $opts['domain'] = $domain;

        $tpls    = $this->list_templates();
        $tpl_def = isset($tpls[$tpl_key]) ? [
            'key'  => $tpls[$tpl_key]['key'],
            'css'  => $tpls[$tpl_key]['css'],
            'html' => $tpls[$tpl_key]['html'],
        ] : null;

        $server_card = '';
        if (!empty($tpls[$tpl_key]['server'])) {
            $country = '';
            $terms   = get_the_terms($post_id, 'country_select');
            if ($terms && !is_wp_error($terms)) {
                $country = $terms[0]->name;
            }
            $base = !empty($opts['server_url']) ? $opts['server_url'] : 'https://api.bnnasia.org/api/v1/photocard.png';
            // The card shows the country separately, so "COUNTRY:" and "ALERT |" are dropped from the headline.
            $card_title = wp_strip_all_tags(html_entity_decode($raw_title, ENT_QUOTES, 'UTF-8'));
            $card_title = preg_replace('/^[^:]{2,40}:\s*/u', '', $card_title);
            $card_title = preg_replace('/^ALERT\s*\|\s*/iu', '', $card_title);
            $server_card = add_query_arg(array(
                'image'   => rawurlencode($image),
                'title'   => rawurlencode($card_title),
                'country' => rawurlencode($country),
                'v'       => '2',
            ), $base);
        }

        wp_send_json_success([
            'server_card' => $server_card,
            'title'   => $title,
            'date'    => $date,
            'image'   => $image,
            'site'    => $site,
            'tpl'     => $tpl_key,
            'opts'    => $opts,
            'tpl_def' => $tpl_def,
        ]);
    }

    public function ajax_get_saved_options() {
        check_ajax_referer('udnpcv36_nonce', '_ajax_nonce', true);
        $key = isset($_POST['key']) ? sanitize_text_field(wp_unslash($_POST['key'])) : '';
        if (empty($key)) wp_send_json_error(['message' => 'Missing key']);
        $opt = get_option(self::OPT_PREFIX . $key, []);
        wp_send_json_success($opt);
    }
}
new UDNPC_Core();

