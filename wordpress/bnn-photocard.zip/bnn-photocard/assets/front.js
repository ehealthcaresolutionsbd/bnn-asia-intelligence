(function($){
  function waitForFonts(){
    return (document.fonts && document.fonts.ready) ? document.fonts.ready : Promise.resolve();
  }

  function downloadCanvas(canvas, filename){
    const a = document.createElement('a');
    a.download = filename;
    a.href = canvas.toDataURL('image/png');
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function showOverlay(){
    if ($('#udnpc-overlay').length) return;
    const overlay = $(`
      <div id="udnpc-overlay" style="
        position:fixed;top:0;left:0;width:100%;height:100%;
        background:rgba(0,0,0,0.85);color:#fff;display:flex;
        flex-direction:column;align-items:center;justify-content:center;
        z-index:999999;font-family:system-ui,sans-serif;font-size:20px;">
        <div class="spinner" style="
          border:4px solid rgba(255,255,255,0.3);
          border-top:4px solid #fff;
          border-radius:50%;
          width:60px;height:60px;
          animation:spin 1s linear infinite;
          margin-bottom:20px;">
        </div>
        <div>Please Wait, We Are Designing a Photo Card</div>
      </div>
      <style>
        @keyframes spin { from{transform:rotate(0deg);} to{transform:rotate(360deg);} }
      </style>
    `);
    $('body').append(overlay);
  }

  function hideOverlay(){
    $('#udnpc-overlay').fadeOut(300, function(){ $(this).remove(); });
  }

  function applyPlaceholders(str, data){
    if(!str) return '';
    str = str.replace(/\{\{\s*title\s*\}\}/g, data.title);
    str = str.replace(/\{\{\s*date\s*\}\}/g, data.date);
    str = str.replace(/\{\{\s*image\s*\}\}/g, data.image);
    str = str.replace(/\{\{\s*site\s*\}\}/g, data.site);
    str = str.replace(/\{\{\s*opt\.([a-zA-Z0-9_\-]+)\s*\}\}/g, function(_, k){
      return (data.opts && data.opts[k]) ? data.opts[k] : '';
    });
    return str;
  }

  function buildFromTemplate(data){
    const wrap = document.createElement('div');
    wrap.style.position = 'fixed';
    wrap.style.left = '-99999px';
    wrap.style.top = '0';
    wrap.style.zIndex = '-1';

    const style = document.createElement('style');
    style.textContent = applyPlaceholders(data.tpl_def.css, data);

    const holder = document.createElement('div');
    holder.innerHTML = applyPlaceholders(data.tpl_def.html, data);

    const card = holder.querySelector('.udnpc-card') || holder.firstElementChild;
    if(card){
      card.style.width = '1080px';
      card.style.height = '1080px';
    }

    wrap.appendChild(style);
    wrap.appendChild(holder);
    document.body.appendChild(wrap);

    return {wrap:wrap, card:card || holder};
  }

  $(document).on('click', '#udnpc-generate', function(){
    const postId = $('#udnpc-postid').val() || 0;
    showOverlay();

    $.post(UDNPCF.ajax, {action:'udnpc_get_card', nonce:UDNPCF.nonce, post_id:postId}, function(resp){
      if(!resp || !resp.success){
        hideOverlay();
        alert((resp && resp.data && resp.data.message) || 'Failed to prepare card');
        return;
      }

      if(resp.data.server_card){
        fetch(resp.data.server_card).then(function(r){
          if(!r.ok) throw new Error('render');
          return r.blob();
        }).then(function(blob){
          const a = document.createElement('a');
          a.download = 'bnn-asia-card-' + Date.now() + '.png';
          a.href = URL.createObjectURL(blob);
          document.body.appendChild(a); a.click(); a.remove();
          hideOverlay();
        }).catch(function(){ hideOverlay(); alert('Rendering failed.'); });
        return;
      }

      const built = buildFromTemplate(resp.data);
      waitForFonts().then(function(){
        setTimeout(function(){
          html2canvas(built.card, {
            backgroundColor: null,
            useCORS: true,
            width: 1080,
            height: 1080,
            scale: 1
          }).then(function(canvas){
            downloadCanvas(canvas, 'news-photocard-' + Date.now() + '.png');
            built.wrap.remove();
            hideOverlay();
          }).catch(function(){
            built.wrap.remove();
            hideOverlay();
            alert('Rendering failed.');
          });
        }, 200);
      });
    }, 'json');
  });
})(jQuery);
